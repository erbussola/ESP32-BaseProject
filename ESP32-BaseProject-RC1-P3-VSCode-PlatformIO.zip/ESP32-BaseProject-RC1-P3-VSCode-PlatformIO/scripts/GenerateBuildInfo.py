print('GenerateBuildInfo placeholder')
