[CmdletBinding()]
param(
    [Parameter(Mandatory)]
    [ValidateSet("Build","Clean","Flash","Monitor","Bootstrap","Version")]
    [string]$Command
)

Import-Module "$PSScriptRoot/Common.psm1" -Force

Write-Info "Comando richiesto: $Command"

switch ($Command) {
    "Build"     { pio run }
    "Clean"     { pio run -t clean }
    "Flash"     { pio run -t upload }
    "Monitor"   { pio device monitor }
    "Bootstrap" { Write-Info "Bootstrap placeholder" }
    "Version"   { Write-Host "2.0.0-RC1" }
}
