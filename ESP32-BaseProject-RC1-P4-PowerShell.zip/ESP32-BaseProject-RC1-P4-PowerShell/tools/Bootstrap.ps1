[CmdletBinding()]
param()

Import-Module "$PSScriptRoot/Common.psm1" -Force

Write-Info "Verifica ambiente..."

git --version
code --version
pio --version

Write-Info "Bootstrap completato."
