# Tools

Contiene gli script PowerShell del progetto.

Script principali:
- Embedded.ps1
- Bootstrap.ps1
- Common.psm1
