# GitHub Actions

Predisposizione per workflow CI.
