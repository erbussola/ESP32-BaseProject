# Quality Assurance

Documentazione QA del progetto.
