# Quality Gates

- Build senza errori
- Nessun warning critico
- Formattazione conforme
- Commit firmati
