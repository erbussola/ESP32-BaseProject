# Piano di Test

- Build
- Flash
- Monitor
- Git
- PlatformIO
