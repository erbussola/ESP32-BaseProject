# Checklist RC1

## Ambiente
- [ ] Git installato
- [ ] VS Code installato
- [ ] PlatformIO installato
- [ ] Driver CP2102 installato

## Repository
- [ ] Clone eseguito
- [ ] Build completata
- [ ] Upload completato
- [ ] Monitor seriale funzionante
