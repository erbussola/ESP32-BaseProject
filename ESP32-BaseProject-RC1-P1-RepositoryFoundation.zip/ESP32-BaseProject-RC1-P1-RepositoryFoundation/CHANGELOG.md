# CHANGELOG

## [2.0.0-RC1]
- Prima release della Repository Foundation.
