# CODE STYLE

Standard di codifica (placeholder).
