# ROADMAP

RC1 Repository Foundation
RC2 Development Environment
RC3 Embedded Framework
RC4 BSP ESP32
RC5 Application Layer
