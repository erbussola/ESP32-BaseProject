# ESP32-BaseProject

Repository Foundation - Release 2.0 RC1

## Obiettivo
Base professionale per lo sviluppo di firmware ESP32 con PlatformIO,
Visual Studio Code e GitLab.
