# RELEASE NOTES

## RC1
- Struttura iniziale del repository
- File di configurazione Git
- Base documentale
