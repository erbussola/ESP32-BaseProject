# Architecture Specification

Versione: 2.0.0-RC1

## Layer
- Application
- Services
- EmbeddedFramework
- HAL
- Board
- Hardware
