# ADR

Registro delle decisioni architetturali.
