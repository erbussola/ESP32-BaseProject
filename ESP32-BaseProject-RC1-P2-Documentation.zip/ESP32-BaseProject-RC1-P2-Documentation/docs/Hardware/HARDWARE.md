# Hardware

Documentazione hardware.
