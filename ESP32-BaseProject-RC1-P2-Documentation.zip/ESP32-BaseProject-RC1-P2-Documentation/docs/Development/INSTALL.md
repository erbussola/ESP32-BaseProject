# Installazione

1. Installare VS Code
2. Installare PlatformIO
3. Clonare il repository
4. Eseguire Bootstrap.ps1
