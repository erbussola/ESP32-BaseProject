# Workflow Git

main, develop, feature/*, bugfix/*, release/*, hotfix/*
