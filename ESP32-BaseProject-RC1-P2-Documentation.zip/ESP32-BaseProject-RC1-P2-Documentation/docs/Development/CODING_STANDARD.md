# Standard di Codifica

C++17, constexpr, enum class, namespace.
